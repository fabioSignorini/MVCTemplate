package com.controller;

import static com.utils.CommonConstants.CONFIG_FILENAME;
import static com.utils.Utils.getPropertiesFromFile;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.model.Model;
import com.view.View;

/**
 * @author Fabio Signorini
 * @version 1.0
 * @see {@link Model} {@link View} {@link ActionListener}
 */
public class Controller implements ActionListener
{
	private Model model 				= null;
	private View view   				= null;
	
	private static final Logger logger	= Logger.getLogger(Controller.class.getName());
	private final String JAVA_TEMP_DIR 	= System.getProperty("java.io.tmpdir");
	private Properties configProperties = new Properties();
	
	/**
	 * The constructor performs some initializations (i.e. {@link Model}, {@link View}, configuration properties, ...).
	 *  
	 * @param model
	 * @param view
	 */
	public Controller(Model model, View view) 
	{
		logger.info("Initializating the Controller...");
		this.model = model;
		this.view = view;
		
		try 
		{
			configProperties = getPropertiesFromFile(CONFIG_FILENAME, configProperties, true);
		}
		catch (FileNotFoundException e)
		{
			logger.error("Unable to find the file " + CONFIG_FILENAME, e);
			e.printStackTrace();
		}
		initView();
		logger.info("...Done!");
	}

	/**
	 * The method performs some initialization instructions.
	 */
	private void initView()
	{
		;
	}
	
	/**
	 * The method set this controller as a listener for the events generated in the {@link View}.
	 */
	public void initController()
	{
		logger.info("Registering the Controller as the listener for the events generated from the interaction with the View...");
		this.view.getButton1().addActionListener(this);
		this.view.getButton2().addActionListener(this);
		logger.info("...Done!");
	}

	/**
	 * The controller interacts with the {@link Model} in order to perform the requested function eventually modifying the state or the data.
	 * This method acts the interaction with the {@link Model} which will be responsible to notify the events to the {@link View}.
	 */
	public void actionPerformed(ActionEvent e) 
	{
		// if (e.getSource() == this.view.getButton1())
		// {
			// this.model.set...
		// }
		// else
		// {
			
		// }
	}
	
}
