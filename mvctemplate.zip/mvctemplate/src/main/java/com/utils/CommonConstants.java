package com.utils;

public final class CommonConstants
{
  
  /**
   * COMMON CONSTANTS
   */
  public static final String CONFIG_FILENAME 			= "config.properties";
  public static final String TEMP_FILE 					= "temp.properties";
  public static final String MISSING_INFO 				= "-";

	/**
	 * The caller references the constants using
	 * <tt>CommonConstants.CONSTANT_FIELD</tt>, and so on. Thus, the caller
	 * should be prevented from constructing objects of this class, by declaring
	 * this private constructor.
	 */
  private CommonConstants()
  {
	  throw new AssertionError();
  }
  
}
