package com.launcher;

import org.apache.log4j.Logger;

import com.controller.Controller;
import com.model.Model;
import com.view.View;

/**
 * Main launcher for the MVC application.
 * After instancing the {@link Model}, the {@link View} and the {@link Controller} we register the {@link Controller} as the listener waiting for the events generated in the interaction with the {@link View}.
 * 
 * @author Fabio Signorini
 * @version 1.0
 * @see {@link Model} {@link View} {@link Controller}
 */
public class Launcher
{
	private static final Logger logger 			= Logger.getLogger(Launcher.class.getName());
	private static final String START_MESSAGE 	= "Initializing application...";
	private static final String END_MESSAGE 	= "Application initialization done!";
	
	public static void main(String[] args) 
	{
		logger.info(START_MESSAGE);
		Model model = new Model();
		View view = new View(model);
		
		Controller controller = new Controller(model, view);
		controller.initController();
		logger.info(END_MESSAGE);
	}
	
}
