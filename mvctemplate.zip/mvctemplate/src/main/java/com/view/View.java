package com.view;

import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;

import org.apache.log4j.Logger;

import com.model.Model;

/**
 * @author Fabio Signorini
 * @version 1.0
 * @see {@link Observer} {@link Model}
 */
public class View implements Observer
{
	private static final Logger logger 	= Logger.getLogger(View.class.getName());
	private JButton button1 			= null;
	private JButton button2 			= null;
	private Model model 				= null;
	private final String TITLE  		= "TITLE"; 

	/**
	 * The constructor performs the initialization and the instantiation of some graphic Widgets.
	 * It uses the {@link Model} to update the graphics according to the current state.
	 *  
	 * @param model the {@link Model} used to maintain the current state.
	 */
	public View(Model model)
	{
		logger.info("Initializating the View...");
		this.model = model;
		this.model.addObserver(this);

		// ...
		this.button1 = new JButton("Button 1");
		this.button2 = new JButton("Button 2");

		initView();
		logger.info("...Done!");
	}
	
	/**
	 * The method performs some initialization instructions using the {@link Model} as the representation of the current state.
	 */
	private void initView()
	{
		;
	}

	/**
	 * This method is called whenever the observed object is changed. 
	 * An application calls an Observable object's {@code notifyObservers} method to have all the object's observers notified of the change.
	 * 
	 * @param o the observable object (i.e. the {@link Model}).
	 * @param arg an argument passed to the {@code notifyObservers} method.
	 */
	public void update(Observable o, Object arg)
	{
		logger.info("Updating the View using the information contained in the Model...");
		Model model = (Model) o;
		if (arg instanceof String)
		{
			;
		}
		else if (arg instanceof Boolean)
		{
			;
		}
		else
		{
			;
		}
		logger.info("...Done!");
	}

	public JButton getButton1() 
	{
		return button1;
	}

	public JButton getButton2() 
	{
		return button2;
	}

}
