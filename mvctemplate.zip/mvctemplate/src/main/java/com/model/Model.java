package com.model;

import static com.utils.CommonConstants.CONFIG_FILENAME;
import static com.utils.CommonConstants.TEMP_FILE;

import java.io.FileNotFoundException;
import java.util.Observable;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.controller.Controller;
import com.utils.Utils;
import com.view.View;

/**
 * @author Fabio Signorini
 * @version 1.0
 * @see {@link Observable}
 */
public class Model extends Observable
{
	private static final Logger logger 			= Logger.getLogger(Model.class.getName());
	private final static String JAVA_TEMP_DIR 	= System.getProperty("java.io.tmpdir");
	private Properties config1 					= null;
	private Properties config2 					= null;
	
	/**
	 * The constructor performs some initializations (i.e. configuration properties, ...).
	 */
	public Model()
	{
		logger.info("Initializating the Model...");
		config1 	= new Properties();
		config2		= new Properties();

		try 
		{
			config2 = Utils.getPropertiesFromFile(CONFIG_FILENAME, config2, true);
		} 
		catch (FileNotFoundException e) 
		{
			logger.error("Unable to find the file " + CONFIG_FILENAME, e);
			e.printStackTrace();
		}
		logger.info("...Done!");
	}
	
	/**
	 * The method is invoked by the {@link Controller} in order to allow for the state modification and the notification towards the {@link View}.
	 * It calls the {@link View#update(Observable, Object)} method in order to update the {@link View} with the new state and the argument passed.
	 * 
	 * @param message an argument useful to the {@link View} in order to display itself.
	 */
	public void M1(String message)
	{
		logger.info("Notifying the View of the state change..." + " (arg is : " + message + ")");
		setChanged();
		notifyObservers(message);
	}
	
	/**
	 * The method is invoked by the {@link Controller} in order to allow for the state modification and the notification towards the {@link View}.
	 * It calls the {@link View#update(Observable, Object)} method in order to update the {@link View} with the new state and the argument passed.
	 * 
	 * @param b an argument useful to the {@link View} in order to display itself.
	 */
	public void M2(boolean b)
	{
		logger.info("Notifying the View of the state change..." + " (arg is : " + b + ")");
		setChanged();
		notifyObservers(b);
	}
	
}
